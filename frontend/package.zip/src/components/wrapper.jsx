import { useLocation, useNavigate } from "react-router-dom";

import React, { useEffect, useRef, useState } from "react";
import { BiMenuAltLeft } from "react-icons/bi";
import { BsPersonLinesFill } from "react-icons/bs";
import { FaCalendar } from "react-icons/fa6";
import { RiFileList3Line } from "react-icons/ri";
import AddPatientModal from "./modal/addPatientModal";
import DeleteConfirmationModal from "./modal/DeleteConfirmationModal";
import { Lock, Pencil, Settings } from "lucide-react";
import moment from "moment";
import useUser from "../hooks/auth/useUser";
import useSelectPatientModal from "../hooks/modal/useSelectPatientModal";
import useFullScreenRecording from "../hooks/useFullScreenRecording";
import useRecordingData from "../hooks/useRecordingData";
import useRecordings from "../hooks/useRecordings";
import useSidebar from "../hooks/useSidebar";
import SelectPatientModal from "./modal/selectPatientModal";
import UserDropdown from "./UserDropdown";
import useToken from "../hooks/auth/useToken";
import TemplateModal from "./modal/TemplateModal/TemplateModal";
import toast from "react-hot-toast";
import useSessionTimeout from "../utils/SessionTimeoutHandler";
import axios from "axios";

const Wrapper = ({ children }) => {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const { subscription, setSubscription } = useUser();
  const toastShown = useRef(false);
  const { isSidebarOpen, setIsSidebarOpen } = useSidebar();
  const { user, setUser } = useUser();

  const { setToken } = useToken();
  const selectPatientModal = useSelectPatientModal();
  const {
    recordings,
    setActiveRecording,
    activeRecording,
    isRecordLoading,
    setTemplateId,
    setTemplateOption,
  } = useRecordings();
  const { patient } = useRecordingData();
  const [isModal, setIsModal] = useState(false);

  console.log(subscription);

  useSessionTimeout(
    () => {
      toast.error("You’ve been logged out due to inactivity.");
      localStorage.removeItem("lastActivity");
      setToken(null);
      navigate("/");
    },
    () => {
      toast(
        "You’ve been inactive. You’ll be logged out soon unless you're active."
      );
    }
  );

  const getPageName = (path) => {
    const pageMap = {
      "/": "Home",
      "/profile": "Edit Profile",
      "/manage-subscription": "Subscription",
      "/subscription": "Pricing Plans",
      "/security": "Security",
      "/recordings": "Patient History",
      "/patient_recordings": "Patient Session",
      "/editor": "Document Editor",
      "/recording": "New Session",
      "/pre_subscription": "Subscription",
    };
    return pageMap[path] || "Dashboard";
  };

  const RecordingComp = ({ recording }) => {
    // eslint-disable-next-line no-unused-vars
    const [isDeleting, setIsDeleting] = React.useState(false);
    const [showDeleteModal, setShowDeleteModal] = React.useState(false);
    const { setShowFullScreenRecording } = useFullScreenRecording();

    return (
      <>
        <div
          onClick={() => {
            setActiveRecording(recording);
            setShowFullScreenRecording(false);
          }}
          className={`${
            recording?.id === activeRecording?.id ? "bg-light_blue" : ""
          } w-full flex flex-col gap-2 cursor-pointer rounded-xl border-[1px] border-text_gray p-2`}
        >
          <div className="flex flex-row w-full items-center justify-between">
            <h1 className="font-semibold">
              {patient?.firstName} {patient?.lastName}
            </h1>
            {/* <BsFillTrashFill
              onClick={handleDeleteClick}
              className={`hover:text-red-500 transition-colors ${
                isDeleting ? "opacity-50" : ""
              }`}
            /> */}
          </div>
          <h1 className="text-text_black font-light">
            {recording?.audio?.duration}
          </h1>
          <div className="flex flex-row items-center justify-between">
            {/* <h1 className="text-gray font-light">{recording?.patient?.id}</h1> */}

            <h1 className="text-gray font-light">
              {moment(recording?.audio?.date).format("MMM DD, YYYY")}
            </h1>
          </div>
        </div>

        <DeleteConfirmationModal
          isOpen={showDeleteModal}
          onClose={() => setShowDeleteModal(false)}
          // onConfirm={handleDelete}
          isDeleting={isDeleting}
        />
      </>
    );
  };

  const menuItems = [
    { label: "Edit Profile", to: "/profile", icon: Pencil },
    { label: "Subscription", to: "/manage-subscription", icon: Settings },
    { label: "Security", to: "/security", icon: Lock },
  ];

  useEffect(() => {
    const fetchSubscription = async () => {
      try {
        const { data } = await axios.post("/v1/api/subscription/details", {
          userId: user.id,
        });
        setSubscription(data);
      } catch (err) {
        console.error("Failed to fetch subscription:", err);
      }
    };

    fetchSubscription();
  }, []);

  useEffect(() => {
    // Wait until user and subscription are fully loaded
    if (user === undefined || subscription === undefined) return;

    if (!user?.status) {
      setToken(null);
      setUser(null);
      navigate("/");
      return;
    }

    if (!user?.isSubscription) {
      if (subscription?.status === "canceled") {
        if (
          pathname !== "/subscription" &&
          pathname !== "/manage-subscription"
        ) {
          navigate("/manage-subscription");
        }
        return;
      }

      // Prevent duplicate toasts
      if (!toastShown.current) {
        toastShown.current = true;
        // Optionally show toast here
      }

      if (pathname !== "/pre_subscription") {
        navigate("/pre_subscription");
      }

      return;
    }

    // If already subscribed and on pre_subscription page, redirect to dashboard
    if (pathname === "/pre_subscription") {
      navigate("/");
    }

    // Reset the toastShown guard when everything is okay
    toastShown.current = false;
  }, [user, subscription, pathname, navigate]);

  useEffect(() => {
    const fetchTemplates = async () => {
      try {
        const response = await axios.get(
          `${process.env.REACT_APP_API_URL}/v1/api/templates/names`
        );

        const templates = response.data?.data || [];

        // Set templateData
        setTemplateOption(templates);

        // Find the "SOAP Note" template
        const soapNote = templates.find(
          (template) => template.templateName === "SOAP Note"
        );

        // Set templateId if found
        if (soapNote) {
          setTemplateId(soapNote.id);
        }
      } catch (error) {
        console.error("Failed to fetch templates", error);
      }
    };

    fetchTemplates();
  }, []);

  return (
    <div className="flex h-screen flex-col">
      <div className="w-full flex flex-row items-center shadow-md justify-between h-[10%]  bg-light_gray p-4">
        <img
          src="/vocalli-logo.png"
          alt="vocalli-logo"
          className="w-44 h-auto"
        />

        <BiMenuAltLeft
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="text-3xl cursor-pointer text-black mx-1 lg:hidden block"
        />

        <div className="hidden md:flex flex-row items-center gap-4  mr-[0px] lg:mr-[200px]">
          <div className="flex flex-row items-center gap-6">
            <h1 className="text-navy_blue font-bold text-lg">
              {getPageName(pathname)}
            </h1>
            <span className="text-soft_gray px-2">|</span>
            <h1 className="text-text_black font-semibold">
              Welcome, {user?.username}
            </h1>
          </div>

          <div className="flex flex-row items-center gap-2 p-2 bg-white rounded-xl">
            <FaCalendar className="text-sm text-soft_gray" />
            <h1 className="font-light text-sm text-soft_gray">
              {moment().format("MMM DD, YYYY")}
            </h1>
          </div>
        </div>

        <UserDropdown user={user} menuItems={menuItems} />
      </div>

      <div className="w-screen h-[90%] flex flex-row">
        <div
          className={` ${
            isSidebarOpen
              ? "min-w-64 w-64 opacity-100 px-4"
              : "w-0 min-w-0 opacity-0 px-0"
          } max-w-64 duration-300 border-r-[1px] border-soft_gray bg-light_gray pb-4 flex flex-col items-center  shrink-0 overflow-y-scroll no-scrollbar  lg:relative lg:h-full  absolute h-[90%] z-[100]`}
        >
          <h1 className="w-full my-4 text-2xl font-bold tracking-wide">
            Recordings
          </h1>
          <div className="flex flex-col gap-2  bg-white rounded-xl px-2 py-4 w-full ">
            <h1 className="font-semibold text-text_black mb-4">
              Start New Recording
            </h1>
            <div
              onClick={() => {
                if (pathname === "/") {
                  selectPatientModal.onOpen();
                } else {
                  navigate("/recording");
                }
              }}
              className="w-full cursor-pointer bg-light_blue rounded-xl flex flex-row items-center justify-center p-1"
            >
              <div className="flex items-center justify-center h-10 w-10 bg-white rounded-full shadow-lg">
                <div className="flex items-center justify-center h-3 w-3 bg-red rounded-full" />
              </div>
              <img src="assets/audio.svg" alt="" />
            </div>
          </div>

          <div
            onClick={() => setIsModal(true)}
            className="w-[255px] cursor-pointer p-3 my-3 bg-white border-r-[2px] border-navy_blue flex items-center justify-start gap-3 hover:bg-light_blue transition px-4"
          >
            <RiFileList3Line className="text-navy_blue text-xl" />
            <h1 className="text-navy_blue font-medium">Template Management</h1>
          </div>

          <div
            onClick={() => navigate("/")}
            className="w-[255px] cursor-pointer p-3 mb-3 bg-white border-r-[2px] border-navy_blue flex items-center justify-start gap-3 hover:bg-light_blue transition px-4"
          >
            <BsPersonLinesFill className="text-navy_blue text-xl" />
            <h1 className="text-navy_blue font-medium">Patient History</h1>
          </div>

          {pathname === "/patient_recordings" && (
            <div className="flex flex-col gap-2  bg-white rounded-xl flex-grow px-2 py-4 w-full mt-5">
              <h1 className="font-semibold text-text_black mb-4">
                {`Previous Recordings`}{" "}
                {!isRecordLoading && (
                  <span className="text-navy_blue font-medium ml-2">{`(${
                    isNaN(recordings?.length)
                      ? 0
                      : recordings?.length > 0
                      ? recordings?.length
                      : 0
                  })`}</span>
                )}
              </h1>
              {isRecordLoading ? (
                <div className="my-auto mx-0">
                  <h1 className="text-gray text-center w-full text-sm font-light">
                    Loading...
                  </h1>
                </div>
              ) : recordings?.length > 0 ? (
                <div className="flex flex-col gap-2">
                  {recordings.map((recording, index) => {
                    return <RecordingComp key={index} recording={recording} />;
                  })}
                </div>
              ) : (
                <div className="my-auto mx-0">
                  <h1 className="text-gray text-center w-full text-sm font-light">
                    Your history will appear here once you create a recording.
                  </h1>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex-grow overflow-y-auto overflow-x-hidden">
          {children}
        </div>
      </div>
      <TemplateModal isModal={isModal} setIsModal={setIsModal} />
      <AddPatientModal />
      <SelectPatientModal />
    </div>
  );
};

export default Wrapper;
