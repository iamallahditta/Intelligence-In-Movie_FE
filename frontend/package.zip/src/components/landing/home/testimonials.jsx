import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";

import { FaArrowLeft, FaArrowRight } from "react-icons/fa6";
import React, { useState } from "react";
import { Swiper, SwiperSlide, useSwiper } from "swiper/react";

const reviews = [
  {
    name: "Anna Julie",
    image:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-K5Wy_yD_JlW5V6d6ApSHnn9W7G48kMcMug&s",
    rating: 5,
    text: "Lorem ipsum dolor sit amet consectetur. Etiam non arcu imperdiet pulvinar donec quis mattis sagittis lacus. Nullam suscipit quisque ullamcorper ac at gravida amet volutpat vitae. Iaculis morbi diam sagittis arcu luctus tristique consectetur. Sodales in arcu tempor porttitor leo ornare congue ut.",
  },
  {
    name: "John Doe",
    image:
      "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=800",
    rating: 4,
    text: "Lorem ipsum dolor sit amet consectetur. Etiam non arcu imperdiet pulvinar donec quis mattis sagittis lacus. Nullam suscipit quisque ullamcorper ac at gravida amet volutpat vitae. Iaculis morbi diam sagittis arcu luctus tristique consectetur. Sodales in arcu tempor porttitor leo ornare congue ut.",
  },
  {
    name: "William",
    image:
      "https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=800",
    rating: 5,
    text: "Lorem ipsum dolor sit amet consectetur. Etiam non arcu imperdiet pulvinar donec quis mattis sagittis lacus. Nullam suscipit quisque ullamcorper ac at gravida amet volutpat vitae. Iaculis morbi diam sagittis arcu luctus tristique consectetur. Sodales in arcu tempor porttitor leo ornare congue ut.",
  },
];

const Testimonials = () => {
  const [swiper, setSwiper] = useState(null);
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <div id='testimonials' className="max-w-[1440px] w-full  mx-auto">
      <div className="flex justify-center items-center">
        <h1 className="text-center mx-auto  text-3xl font-bold text-black tracking-wide border-b-[4px] border-navy_blue inline-block p-[4px]">
          Testimonials
        </h1>
      </div>

      <div className="flex flex-row items-center mx-2 lg:mx-5 xl:mx-10  mt-8 gap-4">
        <div
          className={`min-w-14 min-h-14 cursor-pointer hidden sm:flex duration-300 rounded-full bg-light_blue   items-center justify-center 
            ${activeIndex === 0 ? "opacity-0" : "opacity-100"}
            `}
          onClick={() => {
            swiper?.slidePrev();
          }}
        >
          <FaArrowLeft className={`text-navy_blue duration-300 text-2xl `} />
        </div>

        <Swiper
          slidesPerView={1}
          onSwiper={setSwiper}
          onSlideChange={(e) => {
            setActiveIndex(e.activeIndex);
          }}
          className="swiper1 "
        >
          {reviews.map((review) => (
            <SwiperSlide className="bg-grose-500  w-full flex flex-col  ">
              <div className="relative border-[1px] border-navy_blue rounded-xl overflow-visible mt-20 mb-3 px-2 py-12  sm:px-5  sm:py-12 lg:py-16 lg:px-16  w-[90%] lg:w-[80%] xl:w-[70%] mx-auto">
                <img
                  src={review.image}
                  className="max-w-32 w-32 h-32 max-h-32 rounded-full object-cover absolute top-0 left-[50%] -translate-x-[50%] -translate-y-[60%] z-[999]"
                />
                <div className="flex flex-col gap-1 ">
                  <h1 className="font-semibold text-center my-2">
                    {review.name}
                  </h1>
                  <p className="text-center font-light text-[#6E6E6E]">
                    {review.text}
                  </p>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>

        <div
          className={`cursor-pointer min-w-14 min-h-14 duration-300 rounded-full bg-light_blue hidden sm:flex items-center justify-center ${
            activeIndex === reviews.length - 1 ? "opacity-0" : "opacity-100"
          }`}
          onClick={() => {
            swiper?.slideNext();
          }}
        >
          <FaArrowRight className={`text-navy_blue duration-300 text-2xl `} />
        </div>
      </div>
      <div className="flex justify-center items-center gap-3">
        <div
          className={`min-w-14 min-h-14 cursor-pointer sm:hidden flex duration-300 rounded-full bg-light_blue   items-center justify-center 
            ${activeIndex === 0 ? "opacity-0" : "opacity-100"}
            `}
          onClick={() => {
            swiper?.slidePrev();
          }}
        >
          <FaArrowLeft className={`text-navy_blue duration-300 text-2xl `} />
        </div>

        <div
          className={`cursor-pointer min-w-14 min-h-14 duration-300 rounded-full bg-light_blue flex sm:hidden items-center justify-center ${
            activeIndex === reviews.length - 1 ? "opacity-0" : "opacity-100"
          }`}
          onClick={() => {
            swiper?.slideNext();
          }}
        >
          <FaArrowRight className={`text-navy_blue duration-300 text-2xl `} />
        </div>
      </div>
    </div>
  );
};

export default Testimonials;
