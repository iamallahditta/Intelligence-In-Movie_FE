import React, { useState } from "react";

import { FaFileMedicalAlt } from "react-icons/fa";
import { FaMicrophoneAlt } from "react-icons/fa";
import { FaPlay } from "react-icons/fa";
import { FaUserGroup } from "react-icons/fa6";
import { IoDocumentText } from "react-icons/io5";
import PlayButton from "../../playButton";

const actions=[
    {
        id:"1",
        title:"Listen Conversation",
        description:"Lorem ipsum dolor sit amet.",
        Icon:<FaMicrophoneAlt className="text-gray text-2xl"/>
    },
    {
        id:"2",
        title:"Streamlines Medical Processes",
        description:"Lorem ipsum dolor sit amet.",
        Icon:<FaUserGroup className="text-gray text-2xl"/>
    },
    {
        id:"3",
        title:"Assembles Medical History Records",
        description:"Lorem ipsum dolor sit amet.",
        Icon:<FaFileMedicalAlt className="text-gray text-2xl"/>
    },
    {
        id:"4",
        title:"Conversation Summary",
        description:"Lorem ipsum dolor sit amet.",
        Icon:<IoDocumentText className="text-gray text-2xl"/>
    }
]

const HowItWorks = () => {
  const [isPlaying, setIsPlaying] = useState(false);

  const toggleVideoPlayback = () => {
    const video = document.getElementById("howItWorksVideo");
    if (video.paused) {
      video.play();
      setIsPlaying(true);
    } else {
      video.pause();
      setIsPlaying(false);
    }
  };
  const [isPlaying2, setIsPlaying2] = useState(false);
  const toggleVideoPlayback2 = () => {
    const video = document.getElementById("howItWorksVideo2");
    if (video.paused) {
      video.play();
      setIsPlaying2(true);
    } else {
      video.pause();
      setIsPlaying2(false);
    }
  };

  return (
    <div className={`max-w-[1440px] w-full mt-5 mx-auto`}>
      <div className="w-[95%] sm:2-[90%] lg:w-[75%] mx-auto  flex flex-col items-center justify-center ">
        <h1 className="text-center text-3xl font-bold text-black tracking-wide border-b-[4px] border-navy_blue inline-block p-[4px]">
          How AI Medical Works
        </h1>
        <p className="text-center  text-gray font-light mt-5">
          Lorem ipsum dolor sit amet consectetur. Sed suspendisse pretium
          dictumst posuere ut eu tellus dui scelerisque. Feugiat convallis
          viverra amet posuere. Turpis eu aliquet at amet euismod. Vitae viverra
          convallis enim ut pretium tincidunt. Faucibus donec massa amet natoque
          vel vel eget.{" "}
        </p>
      </div>
      <div className="flex flex-col mx-2 sm:mx-5 lg:mx-10 items-center my-5">
        <div className="flex flex-col md:flex-row items-center bg-[#FAFAFA] my-4 mx-auto">
          <div className="md:w-[55%] w-full  relative overflow-hidden">
            <video
              id="howItWorksVideo"
              className="w-full rounded-xl overflow-hidden"
              src="http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
              poster="/assets/thumbnail2.png"
              controls={false}
            />

            <div
              className={`absolute inset-0 flex items-center rounded-xl  justify-center  text-white text-xl`}
              onClick={toggleVideoPlayback}
            >
              <PlayButton isPlaying={isPlaying} />
            </div>
          </div>
          <div className=" md:w-[45%] w-full p-4">
            <h1 className="text-2xl font-medium text-black mb-4">
              AI Medical{" "}
            </h1>
            <p className="text-gray text-sm  font-light">
              Lorem ipsum dolor sit amet consectetur. Sed suspendisse pretium
              dictumst posuere ut eu tellus dui scelerisque. Feugiat convallis
              viverra amet posuere. Turpis eu aliquet at amet euismod. Vitae
              viverra convallis enim ut pretium tincidunt. Faucibus donec massa
              amet natoque vel vel eget.
              <br />
              egestas mauris at nunc nec in sit fermentum. Feugiat sem id
              convallis egestas aliquam. Pellentesque ullamcorper sapien
              hendrerit urna. Facilisis quis dolor tempor mauris nunc. Rutrum
              non ultricies quam quam dolor. Lectus eget aliquet convallis sit
              tellus elementum nulla purus. Bibendum turpis id bibendum placerat
              lacus id. Imperdiet adipiscing cras est faucibus justo vitae in in
              non. Ac at.{" "}
            </p>
          </div>
        </div>

        <div className="flex flex-col md:flex-row items-center bg-[#FAFAFA] my-4 mx-auto">
          <div className="md:w-[45%] w-full p-4">
            <h1 className="text-2xl font-medium text-black mb-4">
              AI Medical{" "}
            </h1>
            <p className="text-gray text-sm  font-light">
              Lorem ipsum dolor sit amet consectetur. Sed suspendisse pretium
              dictumst posuere ut eu tellus dui scelerisque. Feugiat convallis
              viverra amet posuere. Turpis eu aliquet at amet euismod. Vitae
              viverra convallis enim ut pretium tincidunt. Faucibus donec massa
              amet natoque vel vel eget.
              <br />
              egestas mauris at nunc nec in sit fermentum. Feugiat sem id
              convallis egestas aliquam. Pellentesque ullamcorper sapien
              hendrerit urna. Facilisis quis dolor tempor mauris nunc. Rutrum
              non ultricies quam quam dolor. Lectus eget aliquet convallis sit
              tellus elementum nulla purus. Bibendum turpis id bibendum placerat
              lacus id. Imperdiet adipiscing cras est faucibus justo vitae in in
              non. Ac at.{" "}
            </p>
          </div>

          <div className="md:w-[55%] w-full  relative overflow-hidden">
            <video
              id="howItWorksVideo2"
              className="w-full rounded-xl overflow-hidden"
              src="http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
              poster="/assets/thumbnail1.png"
              controls={false}
            />

            <div
              className={`absolute inset-0 flex items-center rounded-xl  justify-center  text-white text-xl`}
              onClick={toggleVideoPlayback2}
            >
              <PlayButton isPlaying={isPlaying2} />
            </div>
          </div>
        </div>
      </div>

      <div className="w-[95%] sm:2-[90%] lg:w-[75%] mx-auto  flex flex-col items-center justify-center ">
        <h1 className="text-center text-3xl font-bold text-black tracking-wide border-b-[4px] border-navy_blue inline-block p-[4px]">
          AI Medical in Action
        </h1>
        <p className="text-center  text-gray font-light mt-5">
          Lorem ipsum dolor sit amet consectetur. Risus mi ut cursus odio.
        </p>
      </div>
      <div className="grid  grid-cols-2 md:grid-cols-4 mt-10 mb-5 gap-5">
        {actions.map((action )=> <div className="flex flex-col items-center justify-center gap-3">
          <div className="w-12 h-12 border-[1px] border-gray rounded-full flex items-center justify-center">
            {action?.Icon}
          </div>
          <h1 className="text-black  font-medium  text-center">{action?.title}</h1>
          <p className="text-gray text-sm font-light text-center">
            {action?.description}
          </p>
        </div>)}
      </div>
    </div>
  );
};

export default HowItWorks;
