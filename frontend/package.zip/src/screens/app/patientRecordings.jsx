import Button from "../../components/Button";
import FullScreenRecording from "../../components/fullScreenRecording";
import PrevRecord from "../../components/prevRecord";
import React, { useEffect } from "react";
import useAddPatientModal from "../../hooks/modal/useAddPatientModal";
import useFullScreenRecording from "../../hooks/useFullScreenRecording";
import { useNavigate } from "react-router-dom";
import useRecordingData from "../../hooks/useRecordingData";
import useRecordings from "../../hooks/useRecordings";
import axios from "axios";
import toast from "react-hot-toast";

const PatientRecordings = () => {

    const {
      activeRecording,
    recordings,
    setRecordings,
    setActiveRecording,
    setIsRecordLoading,
    isRecordLoading,
  } = useRecordings();

  const {patient}=useRecordingData()

  const navigate=useNavigate()
  const addPatientModal = useAddPatientModal();
  const { showFullScreenRecording } = useFullScreenRecording();

    const fetchRecordings = async () => {
     
    try {
      if (!patient?.id) {
        console.log("No patient ID available");
        navigate("/recordings")
        return;
      }

      const { data } = await axios.get(`/v1/api/record/patient/${patient.id}`);

      console.log("data is", data);
      setRecordings(data?.data?.records);
      setActiveRecording(data?.data?.records?.[0])
      setIsRecordLoading(false);
    } catch (error) {
      console.log("Error fetching recordings:", error);
      toast.error("Something went wrong!");
      setRecordings([]); // Set empty array on error
      setIsRecordLoading(false);
    }
  };

  useEffect(() => {
    setIsRecordLoading(true);
    fetchRecordings();
  }, [patient]);
  return activeRecording ? (
    showFullScreenRecording ? <FullScreenRecording /> : <PrevRecord />
  ) : (
    <div className="flex flex-col  w-full h-full">
      <div className="w-full h-full flex flex-col items-center justify-center">
        <h1 className="text-2xl font-bold">Welcome to AI Medical!</h1>
        <h2 className="font-light my-3 text-center mx-2">
          Get started by creating your first recording or entering patient
          information.
        </h2>
        <div className="w-[150px]">
          <Button onClick={()=>{
            if(patient)
            {
              navigate('/recording')
            }
          }} label="Start Recording" />
        </div>
      </div>
    </div>
  );
};

export default PatientRecordings;
