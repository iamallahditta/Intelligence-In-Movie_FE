import { Route, Routes } from "react-router-dom";

import axios from "axios";
import { useEffect } from "react";
import Wrapper from "../components/wrapper";
import usePatients from "../hooks/usePatients";
import useRecordings from "../hooks/useRecordings";
import AllPatients from "../screens/app/allPatients";
import AllRecordings from "../screens/app/allRecordings";
import EditorPage from "../screens/app/editor";
import ManageSubscription from "../screens/app/manageSubscription";
import PatientRecordings from "../screens/app/patientRecordings";
import Profile from "../screens/app/profile";
import Recording from "../screens/app/recording";
import Subscription from "../screens/app/subscription";
import PreSubscription from "../screens/app/preSubscription";
import Security from "../screens/app/Security";

// const NotFound = () => {
//   return (
//     <div className="flex h-full w-full  items-center justify-center text-3xl font-bold">
//       Not Found!
//     </div>
//   );
// };

export function AppNavigation() {
  const { setRecordings } = useRecordings();
  const { setPatients, setLoading } = usePatients();

  useEffect(() => {


    axios
      .get("/v1/api/patients")
      .then((resp) => {
        console.log(resp?.data?.data.patients);
        setPatients(resp?.data?.data?.patients);
        setLoading(false);
      })
      .catch((err) => {
        console.log(err);
        setLoading(false);
        setPatients([]);
      });
  }, []);
  return (
    <Wrapper>
      <Routes>
        <Route path="/" element={<AllPatients />} />
        <Route path="/recordings" element={<AllRecordings />} />
        <Route path="/patient_recordings" element={<PatientRecordings />} />
        <Route path="/recording" element={<Recording />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/editor" element={<EditorPage />} />
        <Route path="/manage-subscription" element={<ManageSubscription />} />
        <Route path="/security" element={<Security />} />
        <Route path="/subscription" element={<Subscription />} />
        <Route path="/pre_subscription" element={<PreSubscription />} />
        {/* <Route path="*" element={<NotFound />} /> */}
      </Routes>
    </Wrapper>
  );
}
